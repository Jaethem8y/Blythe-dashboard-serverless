def pytest_setup_options():
    """Called before webdriver is initialized."""
